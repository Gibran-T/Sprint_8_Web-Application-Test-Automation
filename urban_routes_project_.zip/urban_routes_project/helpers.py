# helpers.py

def is_reachable(url):
    # Simulação de verificação de conexão
    if url:
        return True
    return False
