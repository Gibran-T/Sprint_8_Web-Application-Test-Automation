def open_browser():
    pass

def login(username, password):
    pass

def select_pickup_point():
    pass

def select_meal():
    pass

def confirm_order():
    pass

def track_order():
    pass
