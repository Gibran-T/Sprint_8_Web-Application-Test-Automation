URBAN_ROUTES_URL = 'https://cnt-112a7ecc-8c7a-451d-9edf-41f2c5bb446a.containerhub.tripleten-services.com?lng=pt'

# Será preenchido depois com o link do servidor

ADDRESS_FROM = 'East 2nd Street, 601'
ADDRESS_TO = '1300 1st St'
PHONE_NUMBER = '+1 123 123 12 12'
CARD_NUMBER = '1234 5678 9100'
CARD_CODE = '1111'
MESSAGE_FOR_DRIVER = 'Pare no bar de sucos'
